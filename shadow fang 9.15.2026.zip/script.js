const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d');
const W = canvas.width, H = canvas.height;

// ---------- audio (synthesized, no external files) ----------
let audioCtx = null, muted = false;
function ac(){ if(!audioCtx) audioCtx = new (window.AudioContext||window.webkitAudioContext)(); return audioCtx; }
function beep(freq, dur, type='square', vol=0.08, slideTo=null){
  if(muted) return;
  try{
    const c = ac();
    const o = c.createOscillator(), g = c.createGain();
    o.type = type; o.frequency.setValueAtTime(freq, c.currentTime);
    if(slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, c.currentTime+dur);
    g.gain.setValueAtTime(vol, c.currentTime);
    g.gain.exponentialRampToValueAtTime(0.001, c.currentTime+dur);
    o.connect(g); g.connect(c.destination);
    o.start(); o.stop(c.currentTime+dur);
  }catch(e){}
}
const sfx = {
  swing: ()=>beep(340,0.07,'square',0.05,220),
  hit: ()=>beep(180,0.09,'square',0.09,90),
  kill: ()=>beep(500,0.15,'triangle',0.08,120),
  dash: ()=>beep(600,0.08,'sine',0.05,900),
  hurt: ()=>beep(120,0.2,'sawtooth',0.09,60),
  fury: ()=>beep(220,0.35,'sawtooth',0.1,700),
  wave: ()=>beep(400,0.25,'triangle',0.07,700),
};
document.getElementById('muteBtn').onclick = (e)=>{
  muted = !muted;
  e.target.textContent = 'SOUND: ' + (muted?'OFF':'ON');
};

// ---------- light / dark theme ----------
// UI chrome (HUD panels, buttons, overlays) is themed via CSS variables on
// body.light — see style.css. The canvas scene itself (sky, moon/sun,
// skyline) is drawn in JS, so it needs its own matching palette.
const SCENE_THEMES = {
  dark: {
    sky:'#0f1622', orb:'#e8f0ff', orbGlow:'rgba(232,240,255,0.08)',
    buildings:'#141d2b', windowLight:'rgba(255,203,71,0.06)',
    ledge:'#1b2531', ledgeLine:'#2a3a52', comboText:'#ffcb47',
  },
  light: {
    sky:'#bfe0fb', orb:'#fff3c4', orbGlow:'rgba(255,243,196,0.45)',
    buildings:'#8fabc4', windowLight:'rgba(255,255,255,0.35)',
    ledge:'#c9dced', ledgeLine:'#93aec6', comboText:'#a8720c',
  },
};
let sceneTheme = SCENE_THEMES.dark;
document.getElementById('themeBtn').onclick = (e)=>{
  const isLight = document.body.classList.toggle('light');
  sceneTheme = isLight ? SCENE_THEMES.light : SCENE_THEMES.dark;
  e.target.textContent = 'THEME: ' + (isLight ? 'LIGHT' : 'DARK');
};

let keys = {};
window.addEventListener('keydown', e => {
  keys[e.key.toLowerCase()] = true;
  if(['arrowup','arrowdown','arrowleft','arrowright',' '].includes(e.key.toLowerCase())) e.preventDefault();
});
window.addEventListener('keyup', e => { keys[e.key.toLowerCase()] = false; });

// FIX: clicking a UI button (mute, retry, etc.) or switching tabs/windows
// steals keyboard focus. The browser then never fires "keyup" for whatever
// movement key was held, so the ninja would get stuck walking/attacking
// forever ("stuck around button"). Clear all held keys whenever focus leaves
// the page, and also on any mouse click, as a safety net.
function clearAllKeys(){ keys = {}; }
window.addEventListener('blur', clearAllKeys);
document.addEventListener('visibilitychange', ()=>{ if(document.hidden) clearAllKeys(); });
document.addEventListener('mouseup', clearAllKeys);

function rectsOverlap(a,b){
  return a.x < b.x+b.w && a.x+a.w > b.x && a.y < b.y+b.h && a.y+a.h > b.y;
}

// ---------- difficulty ----------
const DIFFICULTIES = {
  normal: {
    label:'normal',
    projectileSpeedMult: 0.65,  // slower projectiles
    throwerWeightMult: 0.55,    // fewer thrower-type enemies spawn
    throwCooldownMult: 1.35,    // throwers fire less often
    playerHpMult: 1.3,          // 30% more max HP
    healMult: 1.3,              // 30% stronger health shards
  },
  hard: {
    label:'hard',
    projectileSpeedMult: 1,
    throwerWeightMult: 1,
    throwCooldownMult: 1,
    playerHpMult: 1,
    healMult: 1,
  },
};
let difficulty = DIFFICULTIES.hard;
document.querySelectorAll('.diffBtn').forEach(btn=>{
  btn.onclick = ()=>{
    document.querySelectorAll('.diffBtn').forEach(b=>b.classList.remove('active'));
    btn.classList.add('active');
    difficulty = DIFFICULTIES[btn.dataset.diff];
  };
});

// ---------- screen shake ----------
let shakeMag = 0;
function shake(m){ shakeMag = Math.max(shakeMag, m); }

// ---------- hit stop (brief freeze on impact for game feel) ----------
let hitStop = 0;

class Player {
  constructor(){
    this.x = W/2; this.y = H/2; this.w=24; this.h=34;
    this.speed=2.7; this.facing=1;
    this.maxHp = Math.round(100*difficulty.playerHpMult); this.hp=this.maxHp;
    this.attackCooldown=0; this.attackTimer=0; this.attacking=false;
    this.comboStep=0; this.comboWindow=0;
    this.dashCooldown=0; this.dashTimer=0; this.dashing=false;
    this.invuln=0;
    this.hitEnemiesThisSwing = new Set();
    this.special = 0; this.maxSpecial = 100;
    this.furyTimer = 0;
    this.bob = 0;
    this.reachBonus = 0;   // from Blade Reach upgrades
    this.resistance = 0;   // from Resistance upgrades, 0-0.7 (fraction of incoming damage blocked)
  }
  update(){
    let dx=0, dy=0;
    if(keys['a']||keys['arrowleft']) dx=-1;
    if(keys['d']||keys['arrowright']) dx=1;
    if(keys['w']||keys['arrowup']) dy=-1;
    if(keys['s']||keys['arrowdown']) dy=1;
    if(dx!==0) this.facing = dx>0?1:-1;

    let sp = this.speed;
    if(this.dashing) sp = 8.5;
    if(this.attacking) sp *= 0.25;

    if(dx!==0||dy!==0){
      const len = Math.hypot(dx,dy);
      this.x += (dx/len)*sp;
      this.y += (dy/len)*sp;
      this.bob += 0.35;
    }
    this.x = Math.max(20, Math.min(W-20, this.x));
    this.y = Math.max(60, Math.min(H-20, this.y));

    // attack input / combo chain
    if((keys['j']||keys[' ']) && this.attackCooldown<=0 && !this.dashing){
      this.attacking = true;
      this.attackTimer = 13;
      this.attackCooldown = this.comboWindow>0 ? 16 : 22;
      this.comboStep = this.comboWindow>0 ? (this.comboStep+1)%3 : 0;
      this.comboWindow = 30;
      this.hitEnemiesThisSwing = new Set();
      sfx.swing();
    }
    if(this.attackTimer>0){ this.attackTimer--; if(this.attackTimer<=0) this.attacking=false; }
    if(this.attackCooldown>0) this.attackCooldown--;
    if(this.comboWindow>0){ this.comboWindow--; if(this.comboWindow<=0) this.comboStep=0; }

    // dash
    if((keys['k']||keys['shift']) && this.dashCooldown<=0 && !this.attacking){
      this.dashing = true; this.dashTimer = 9; this.dashCooldown = 36;
      this.invuln = 14;
      sfx.dash();
    }
    if(this.dashTimer>0){ this.dashTimer--; if(this.dashTimer<=0) this.dashing=false; }
    if(this.dashCooldown>0) this.dashCooldown--;
    if(this.invuln>0) this.invuln--;

    // fury strike
    if(keys['l'] && this.special>=this.maxSpecial && this.furyTimer<=0){
      this.furyTimer = 18;
      this.special = 0;
      shake(10);
      sfx.fury();
    }
    if(this.furyTimer>0) this.furyTimer--;

    document.getElementById('specialFill').style.width = (this.special/this.maxSpecial*100)+'%';
  }
  hitbox(){
    if(this.furyTimer>10) return {x:this.x-70,y:this.y-70,w:140,h:140, fury:true};
    if(!this.attacking) return null;
    const reach = 24 + this.comboStep*4 + this.reachBonus;
    return {x: this.facing>0? this.x+8 : this.x-8-reach, y:this.y-15, w:reach, h:30};
  }
  body(){ return {x:this.x-this.w/2,y:this.y-this.h/2,w:this.w,h:this.h}; }
  draw(){
    ctx.save();
    ctx.translate(this.x,this.y);
    ctx.fillStyle='rgba(0,0,0,0.4)';
    ctx.beginPath(); ctx.ellipse(0,16,14,5,0,0,Math.PI*2); ctx.fill();

    ctx.scale(this.facing,1);
    if(this.invuln>0){ ctx.globalAlpha=0.55+0.45*Math.sin(Date.now()/40); }
    const bobOff = Math.sin(this.bob)*1.5;

    ctx.fillStyle = this.furyTimer>0 ? '#3ef2c4' : '#1b2733';
    ctx.fillRect(-9,-16+bobOff,18,28);
    ctx.fillStyle = this.furyTimer>0 ? '#ffcb47' : '#3ef2c4';
    ctx.fillRect(-9,-2+bobOff,18,4);
    ctx.fillStyle = '#0d1117';
    ctx.fillRect(-8,-24+bobOff,16,12);
    ctx.fillStyle = '#e8f0ff';
    ctx.fillRect(-5,-19+bobOff,4,3);
    ctx.fillRect(2,-19+bobOff,4,3);
    ctx.fillStyle='#131c26';
    ctx.fillRect(-8,12+bobOff,6,8);
    ctx.fillRect(2,12+bobOff,6,8);

    if(this.attacking){
      ctx.strokeStyle = this.comboStep===2 ? '#ff4d5e' : '#ffcb47';
      ctx.lineWidth = 3 + this.comboStep;
      ctx.beginPath();
      const t = 1-(this.attackTimer/13);
      ctx.arc(10,-4,24+this.comboStep*4, -0.9+t*1.6, -0.2+t*1.6);
      ctx.stroke();
    }
    if(this.furyTimer>10){
      ctx.strokeStyle='rgba(62,242,196,0.5)';
      ctx.lineWidth=2;
      ctx.beginPath(); ctx.arc(0,0,70/this.facing*this.facing,0,Math.PI*2); ctx.stroke();
    }
    ctx.restore();
  }
}

class Enemy {
  constructor(x,y,kind){
    this.x=x; this.y=y; this.w=22; this.h=32;
    this.kind = kind; // 'grunt' | 'brute' | 'thrower' | 'bomber' | 'shielded' | 'boss'
    const stats = {
      grunt:{hp:16, speed:1.7, dmg:8, range:32},
      brute:{hp:44, speed:1.0, dmg:15, range:36},
      thrower:{hp:12, speed:1.3, dmg:6, range:150},
      bomber:{hp:10, speed:2.6, dmg:22, range:24},
      shielded:{hp:26, speed:1.3, dmg:10, range:34},
      boss:{hp:160, speed:0.9, dmg:20, range:44},
    }[kind];
    this.hp = stats.hp; this.maxHp = stats.hp;
    this.speed = stats.speed; this.dmg = stats.dmg; this.range = stats.range;
    this.dead=false;
    this.hitFlash=0;
    this.telegraph=0;
    this.contactCooldown=0;
    this.throwCooldown = (60+Math.random()*60) * difficulty.throwCooldownMult;
    this.throwWindup = 0; // frames spent charging a visible throw telegraph
    this.knockX=0; this.knockY=0;
  }
  update(p, projectiles){
    if(this.dead) return;
    // knockback decay
    if(Math.abs(this.knockX)>0.1 || Math.abs(this.knockY)>0.1){
      this.x += this.knockX; this.y += this.knockY;
      this.knockX *= 0.85; this.knockY *= 0.85;
    }
    const dx = p.x-this.x, dy=p.y-this.y;
    const dist = Math.hypot(dx,dy)||1;

    if(this.kind==='bomber'){
      // VARIETY: fast suicide rusher. Closes distance quickly and detonates
      // on contact for a big single hit, rather than chipping away like
      // other melee types. Killable in 1-2 hits if you catch it at range.
      if(dist > this.range){
        this.x += (dx/dist)*this.speed;
        this.y += (dy/dist)*this.speed;
        this.telegraph = 0;
      } else {
        this.telegraph++;
        if(this.telegraph > 16){
          if(p.invuln<=0){
            p.hp -= this.dmg * (1-(p.resistance||0));
            p.invuln = 30;
            sfx.hurt(); shake(9);
          }
          spark(this.x, this.y, '#ff8a3d', 16);
          this.dead = true; // self-destructs, no kill score for the player
        }
      }
    } else if(this.kind==='thrower'){
      if(dist > 90){
        this.x += (dx/dist)*this.speed;
        this.y += (dy/dist)*this.speed;
      } else if(dist < 60){
        this.x -= (dx/dist)*this.speed;
        this.y -= (dy/dist)*this.speed;
      }
      this.throwCooldown--;
      // DEBUFF: throwers now telegraph for 26 frames (~0.4s) before firing —
      // a visible wind-up (growing red glow) gives you a real window to dash
      // away or close the distance and cut them down before the shot fires.
      if(this.throwCooldown<=26 && this.throwCooldown>0){
        this.throwWindup = 26 - this.throwCooldown;
      }
      if(this.throwCooldown<=0){
        this.throwCooldown = 140 * difficulty.throwCooldownMult;
        this.throwWindup = 0;
        const aimx = p.x-this.x, aimy = p.y-this.y;
        const aimd = Math.hypot(aimx,aimy)||1;
        const spd = 3.4 * difficulty.projectileSpeedMult;
        projectiles.push({x:this.x,y:this.y,vx:(aimx/aimd)*spd,vy:(aimy/aimd)*spd,life:120,dmg:this.dmg});
      }
    } else if(dist > this.range){
      this.x += (dx/dist)*this.speed;
      this.y += (dy/dist)*this.speed;
    } else {
      this.telegraph++;
      const trigger = this.kind==='boss'?45:50;
      if(this.telegraph>trigger){
        this.telegraph=0;
        if(this.contactCooldown<=0 && p.invuln<=0){
          p.hp -= this.dmg * (1-(p.resistance||0));
          p.invuln = 30;
          this.contactCooldown=30;
          sfx.hurt();
          shake(6);
        }
      }
    }
    if(this.contactCooldown>0) this.contactCooldown--;
    if(this.hitFlash>0) this.hitFlash--;
  }
  body(){ return {x:this.x-this.w/2,y:this.y-this.h/2,w:this.w,h:this.h}; }
  draw(){
    if(this.dead) return;
    ctx.save();
    ctx.translate(this.x,this.y);
    ctx.fillStyle='rgba(0,0,0,0.4)';
    ctx.beginPath(); ctx.ellipse(0,16,13,5,0,0,Math.PI*2); ctx.fill();

    const flashy = this.hitFlash>0;
    const scale = this.kind==='brute'?1.25 : this.kind==='boss'?1.7 : this.kind==='shielded'?1.1 : 1;
    const palette = {grunt:'#3a2e42', brute:'#5a2e3a', thrower:'#2e4a4a', bomber:'#5a3a1f', shielded:'#26314a', boss:'#4a1f2e'}[this.kind];
    ctx.fillStyle = flashy? '#ffffff' : palette;
    ctx.fillRect(-9*scale,-16*scale,18*scale,28*scale);
    const stripe = {grunt:'#ff4d5e', brute:'#ff4d5e', thrower:'#3ef2c4', bomber:'#ffcb47', shielded:'#7fb3ff', boss:'#ff4d5e'}[this.kind];
    ctx.fillStyle= flashy? '#ffffff' : stripe;
    ctx.fillRect(-6*scale,-10*scale,12*scale,3);

    if(this.kind==='shielded'){
      ctx.strokeStyle = flashy? '#ffffff' : '#7fb3ff';
      ctx.lineWidth = 3;
      ctx.beginPath(); ctx.arc(0,-2,15*scale,-2.0,2.0); ctx.stroke();
    }

    if(this.telegraph>28 && this.kind!=='bomber'){
      ctx.strokeStyle='rgba(255,77,94,0.8)';
      ctx.lineWidth=2;
      ctx.beginPath(); ctx.arc(0,0,this.range*0.6,0,Math.PI*2); ctx.stroke();
    }
    if(this.throwWindup>0){
      const t = this.throwWindup/26;
      ctx.fillStyle = `rgba(255,77,94,${0.15+t*0.5})`;
      ctx.beginPath(); ctx.arc(0,-4,4+t*7,0,Math.PI*2); ctx.fill();
    }
    if(this.kind==='bomber' && this.telegraph>0){
      const t = this.telegraph/16;
      ctx.strokeStyle = `rgba(255,138,61,${0.3+t*0.6})`;
      ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(0,0,10+t*40,0,Math.PI*2); ctx.stroke();
    }

    ctx.fillStyle='#22303f';
    ctx.fillRect(-14*scale/1.3,-26*scale,24*scale/1.3*1.3,3);
    ctx.fillStyle='#ff4d5e';
    ctx.fillRect(-14*scale/1.3,-26*scale,24*scale/1.3*(this.hp/this.maxHp),3);
    ctx.restore();
  }
}

let player, enemies, particles, projectiles, pickups, wave, score, combo, comboTimer, running, cam;

// initialize immediately so the render loop always has valid state,
// even before the player clicks "Start" on the title screen
player = new Player();
enemies = [];
particles = [];
projectiles = [];
pickups = [];
wave = 1;
score = 0;
combo = 0;
comboTimer = 0;
running = false;
cam = {x:0,y:0};
let waveTransition = false;

function resetGame(){
  player = new Player();
  enemies = [];
  particles = [];
  projectiles = [];
  pickups = [];
  wave = 1;
  score = 0;
  combo = 0;
  comboTimer = 0;
  running = true;
  waveTransition = false;
  cam = {x:0,y:0};
  showWaveBanner('WAVE 1');
  spawnWave();
}

function showWaveBanner(text){
  const el = document.getElementById('waveBanner');
  el.textContent = text;
  el.style.opacity = 1;
  setTimeout(()=>{ el.style.opacity = 0; }, 1100);
}

// ---------- post-boss upgrade selection ----------
const UPGRADES = {
  reach: { name:'Blade Reach', apply: p => { p.reachBonus += 4; } },
  vitality: { name:'Vitality', apply: p => { p.maxHp += 25; p.hp = p.maxHp; } },
  resistance: { name:'Resistance', apply: p => { p.resistance = Math.min(0.7, p.resistance + 0.15); } },
};
let upgradeTimerId = null;

function openUpgradeSelect(onDone){
  running = false; // freeze the fight while choosing
  const overlay = document.getElementById('upgrade');
  const timerEl = document.getElementById('upgradeTimer');
  overlay.style.display = 'flex';

  let secondsLeft = 20;
  timerEl.textContent = `Auto-selecting in ${secondsLeft}s…`;

  const finish = (key)=>{
    clearInterval(upgradeTimerId);
    upgradeTimerId = null;
    overlay.style.display = 'none';
    document.querySelectorAll('.upgradeBtn').forEach(b=>b.onclick=null);
    document.getElementById('skipUpgrade').onclick = null;
    if(key) UPGRADES[key].apply(player);
    clearAllKeys();
    running = true;
    onDone();
  };

  document.querySelectorAll('.upgradeBtn').forEach(btn=>{
    btn.onclick = ()=> finish(btn.dataset.upgrade);
  });
  document.getElementById('skipUpgrade').onclick = ()=> finish(null);

  upgradeTimerId = setInterval(()=>{
    secondsLeft--;
    if(secondsLeft<=0){
      const upgradeKeys = Object.keys(UPGRADES);
      finish(upgradeKeys[Math.floor(Math.random()*upgradeKeys.length)]);
    } else {
      timerEl.textContent = `Auto-selecting in ${secondsLeft}s…`;
    }
  }, 1000);
}

function pickEnemyKind(){
  // weighted pool — grows richer as waves progress
  const pool = [{k:'grunt', w:10}];
  if(wave>=2) pool.push({k:'brute', w:6});
  if(wave>=3) pool.push({k:'thrower', w:6*difficulty.throwerWeightMult});
  if(wave>=4) pool.push({k:'shielded', w:5});
  if(wave>=5) pool.push({k:'bomber', w:4});
  const total = pool.reduce((s,p)=>s+p.w,0);
  let r = Math.random()*total;
  for(const p of pool){ if(r<p.w) return p.k; r-=p.w; }
  return 'grunt';
}

function spawnWave(){
  const isBossWave = wave % 5 === 0;
  if(isBossWave){
    enemies.push(new Enemy(W/2, 100, 'boss'));
    sfx.wave();
    return;
  }
  const count = 3 + wave;
  for(let i=0;i<count;i++){
    const angle = Math.random()*Math.PI*2;
    const dist = 220 + Math.random()*80;
    let x = W/2 + Math.cos(angle)*dist;
    let y = H/2 + Math.sin(angle)*dist;
    x = Math.max(30,Math.min(W-30,x));
    y = Math.max(70,Math.min(H-30,y));
    enemies.push(new Enemy(x,y,pickEnemyKind()));
  }
  sfx.wave();
}

function spark(x,y,color,n=8){
  for(let i=0;i<n;i++){
    particles.push({
      x,y, vx:(Math.random()-0.5)*4, vy:(Math.random()-0.5)*4,
      life:20, maxLife:20, color
    });
  }
}

function damageEnemy(en, amount, kx, ky, blocked){
  en.hp -= amount;
  en.hitFlash = 6;
  en.knockX = kx; en.knockY = ky;
  spark(en.x, en.y, blocked ? '#7a8aa0' : '#ffcb47');
  player.special = Math.min(player.maxSpecial, player.special + 4);
  combo++; comboTimer = 90;
  hitStop = 4;
  sfx.hit();
  if(en.hp<=0 && !en.dead){
    en.dead = true;
    const base = {grunt:100,brute:250,thrower:150,bomber:180,shielded:200,boss:1500}[en.kind];
    score += base * Math.max(1, Math.floor(combo/5));
    spark(en.x, en.y, '#ff4d5e', 14);
    sfx.kill();
    shake(en.kind==='boss'?14:4);

    // HEAL OPTION: capped, chance-based health shards. Kept deliberately
    // modest (a handful of HP, low drop rate) so it's a way to recover from
    // chip damage without turning fights into a free-heal loop. Riskier
    // kills are more likely to drop one, rewarding players for pushing in
    // rather than just avoiding them.
    const dropChance = {grunt:0.08, brute:0.22, thrower:0.22, bomber:0.2, shielded:0.18, boss:1.0}[en.kind];
    if(Math.random() < dropChance){
      const heal = Math.round((en.kind==='boss'?30:8) * difficulty.healMult);
      pickups.push({x:en.x, y:en.y, heal, dead:false, bob:Math.random()*10});
    }
  }
}

function update(){
  if(!running) return;
  if(hitStop>0){ hitStop--; return; }

  player.update();

  const hb = player.hitbox();
  enemies.forEach(en=>{
    en.update(player, projectiles);
    if(hb && !en.dead && rectsOverlap(hb, en.body()) && !player.hitEnemiesThisSwing.has(en)){
      player.hitEnemiesThisSwing.add(en);
      let dmg = hb.fury ? 6 : (10 + player.comboStep*4);
      let blocked = false;
      // VARIETY: shielded enemies reduce frontal damage — but a dash (or the
      // brief invulnerability right after one) counts as flanking past the
      // shield for full damage, rewarding aggressive positioning over just
      // mashing the attack button.
      if(en.kind==='shielded' && !(player.dashing || player.invuln>0)){
        dmg = Math.round(dmg*0.45);
        blocked = true;
      }
      const dx = en.x-player.x, dy=en.y-player.y;
      const dl = Math.hypot(dx,dy)||1;
      damageEnemy(en, dmg, (dx/dl)*6, (dy/dl)*6, blocked);
    }
  });

  // projectiles
  projectiles.forEach(pr=>{
    pr.x += pr.vx; pr.y += pr.vy; pr.life--;
    // COUNTERPLAY: a live sword swing or fury strike knocks projectiles out
    // of the air instead of just eating chip damage every time.
    if(hb && rectsOverlap(hb, {x:pr.x-4,y:pr.y-4,w:8,h:8})){
      pr.life = 0;
      spark(pr.x, pr.y, '#3ef2c4', 6);
    } else if(player.invuln<=0 && Math.hypot(pr.x-player.x, pr.y-player.y) < 16){
      player.hp -= (pr.dmg || 6) * (1-(player.resistance||0)); player.invuln = 30; pr.life=0;
      sfx.hurt(); shake(5);
    }
  });
  projectiles = projectiles.filter(pr=>pr.life>0 && pr.x>-20 && pr.x<W+20 && pr.y>-20 && pr.y<H+20);

  // health shards: small, capped healing so there's a way back from chip
  // damage without making the player unkillable
  pickups.forEach(pk=>{
    if(!pk.dead && Math.hypot(pk.x-player.x, pk.y-player.y) < 18){
      pk.dead = true;
      player.hp = Math.min(player.maxHp, player.hp + pk.heal);
      spark(pk.x, pk.y, '#7dffb0', 10);
      sfx.kill();
    }
  });
  pickups = pickups.filter(pk=>!pk.dead);

  enemies = enemies.filter(en=>!en.dead);

  if(comboTimer>0){ comboTimer--; if(comboTimer<=0) combo=0; }

  particles.forEach(p=>{ p.x+=p.vx; p.y+=p.vy; p.life--; });
  particles = particles.filter(p=>p.life>0);

  if(shakeMag>0) shakeMag *= 0.85;
  if(shakeMag<0.1) shakeMag=0;

  if(enemies.length===0 && !waveTransition){
    const clearedWave = wave;
    wave++;
    document.getElementById('waveNum').textContent = wave;
    waveTransition = true;
    if(clearedWave % 5 === 0){
      // a captain just fell — offer an upgrade before the next wave
      openUpgradeSelect(()=>{
        showWaveBanner('WAVE '+wave);
        setTimeout(()=>{ spawnWave(); waveTransition = false; }, 200);
      });
    } else {
      showWaveBanner(wave%5===0 ? 'CAPTAIN INCOMING' : 'WAVE '+wave);
      setTimeout(()=>{ spawnWave(); waveTransition = false; }, wave%5===0 ? 800 : 200);
    }
  }

  document.getElementById('score').textContent = score;
  const hpPct = Math.max(0,player.hp);
  document.getElementById('hpFill').style.width = hpPct + '%';
  const ghost = document.getElementById('hpGhost');
  if(parseFloat(ghost.style.width)||100 > hpPct) ghost.style.width = hpPct + '%';

  if(player.hp<=0){
    running=false;
    document.getElementById('finalScore').textContent = `Final score: ${score} — reached wave ${wave}`;
    document.getElementById('over').style.display='flex';
  }
}

function drawRooftop(){
  ctx.fillStyle = sceneTheme.sky;
  ctx.fillRect(0,0,W,H);

  ctx.fillStyle = sceneTheme.orb;
  ctx.beginPath(); ctx.arc(W-70,60,26,0,Math.PI*2); ctx.fill();
  ctx.fillStyle = sceneTheme.orbGlow;
  ctx.beginPath(); ctx.arc(W-70,60,46,0,Math.PI*2); ctx.fill();

  ctx.fillStyle = sceneTheme.buildings;
  for(let i=0;i<10;i++){
    ctx.fillRect(i*80-10, 40+ (i%3)*10, 60, 400);
  }
  // faint window lights
  ctx.fillStyle = sceneTheme.windowLight;
  for(let i=0;i<24;i++){
    ctx.fillRect((i*37)%W, 50+((i*53)%160), 4,4);
  }

  ctx.fillStyle = sceneTheme.ledge;
  ctx.fillRect(0, H-40, W, 40);
  ctx.strokeStyle = sceneTheme.ledgeLine;
  ctx.lineWidth=2;
  ctx.beginPath();
  for(let x=0;x<W;x+=40){ ctx.moveTo(x,H-40); ctx.lineTo(x,H); }
  ctx.stroke();

  if(combo>1){
    ctx.fillStyle = sceneTheme.comboText;
    ctx.font='bold 16px Courier New';
    ctx.textAlign='center';
    ctx.fillText(`${combo}x COMBO`, W/2, 40);
  }
}

function draw(){
  ctx.save();
  if(shakeMag>0){
    ctx.translate((Math.random()-0.5)*shakeMag, (Math.random()-0.5)*shakeMag);
  }
  drawRooftop();
  enemies.forEach(en=>en.draw());

  projectiles.forEach(pr=>{
    ctx.fillStyle = '#3ef2c4';
    ctx.beginPath(); ctx.arc(pr.x,pr.y,4,0,Math.PI*2); ctx.fill();
  });

  pickups.forEach(pk=>{
    pk.bob += 0.08;
    const yOff = Math.sin(pk.bob)*3;
    ctx.save();
    ctx.translate(pk.x, pk.y+yOff);
    ctx.fillStyle = 'rgba(125,255,176,0.25)';
    ctx.beginPath(); ctx.arc(0,0,10,0,Math.PI*2); ctx.fill();
    ctx.fillStyle = '#7dffb0';
    ctx.beginPath();
    ctx.moveTo(0,-6); ctx.lineTo(5,0); ctx.lineTo(0,6); ctx.lineTo(-5,0);
    ctx.closePath(); ctx.fill();
    ctx.restore();
  });

  player.draw();
  particles.forEach(p=>{
    ctx.fillStyle = p.color;
    ctx.globalAlpha = p.life/p.maxLife;
    ctx.fillRect(p.x-2,p.y-2,4,4);
    ctx.globalAlpha=1;
  });
  ctx.restore();
}

function loop(){
  update();
  draw();
  requestAnimationFrame(loop);
}

document.getElementById('startBtn').onclick = ()=>{
  document.getElementById('title').style.display='none';
  resetGame();
};
document.getElementById('retryBtn').onclick = ()=>{
  document.getElementById('over').style.display='none';
  resetGame();
};

loop();
