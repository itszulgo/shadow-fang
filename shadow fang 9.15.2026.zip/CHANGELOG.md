# Shadow Fang — Changelog

A running account, in my own words, of how this project came together, in the order it happened.

---

### 1. First build — the game is born
You asked for "something as cool as TMNT." I asked a couple of clarifying questions
(playable game vs. written concept, hero type) and then built the first version of
**Shadow Fang**: a single self-contained HTML file with one hero (Kestrel), two enemy
types (grunt, brute), wave spawning, a basic sword swing, a dash, and a score counter.

### 2. "Improve it" — depth pass
I added more combat depth on top of the v1 skeleton:
- Turned single-hit attacks into a 3-hit combo chain with growing reach/damage
- Added a **Fury Strike** special (AoE hit, charges up as you land hits)
- Added a new enemy type: the **thrower**, which keeps its distance and lobs projectiles
- Added **boss waves** every 5th wave
- Added screen shake, a brief hit-stop freeze on impact, and knockback for game feel
- Added synthesized sound effects (no audio files) with a mute toggle

### 3. "There is no ninja in my window" — first real bug
I tracked down the cause: my render loop started running before you clicked "Start," and
it tried to draw a ninja that didn't exist yet. That crash killed the entire animation
loop on the very first frame, so even after clicking Start, nothing ever rendered again.
I fixed the startup order so game state is always valid before the loop begins, and
removed a leftover debug hack in the wave-transition logic that could have caused a
similar issue later.

### 4. "Separate the CSS and JavaScript files, this is a mess"
I'd kept everything in one HTML file for simplicity. I split it into a proper three-file
structure: `index.html` (markup only), `style.css` (all styling), `script.js` (all game
logic) — linked together instead of inlined.

### 5. Stuck ninja + unfair throwers — balance and bug pass
You reported two issues together.
- **Stuck character:** I dug into why it happened "around buttons" specifically. The
  cause: clicking any UI button (like Mute) while holding a movement key stole keyboard
  focus, so the browser never fired the key-up event — the game thought that key was held
  forever. I fixed it by clearing all held keys whenever the page loses focus, the tab is
  hidden, or you click anywhere.
- **Throwers too punishing:** I considered just lowering their damage, but that alone
  wouldn't have given you any real counterplay. Instead I gave throwers a visible wind-up
  before firing, let your sword (or Fury Strike) deflect and destroy incoming projectiles,
  dropped thrower damage from 8 to 6, and added a chance for defeated enemies (weighted
  toward riskier kills like throwers and brutes) to drop a small, capped health shard — a
  way to recover HP without it being free sustain.

### 6. Difficulty modes, post-boss upgrades, enemy variety
You asked for three things at once, so I mapped them onto the existing systems rather than
bolting on something disconnected:
- Added a **difficulty picker** on the title screen. I kept the existing balance as "Hard"
  and added a new "Normal" mode with slower projectiles, fewer thrower-type spawns, +30%
  player max HP, and +30% stronger health shards
- Added a **post-boss upgrade screen**: after every captain fight, I pause the game for up
  to 20 seconds (skippable) and offer a choice of Blade Reach (+sword range), Vitality
  (+max HP, full heal), or Resistance (−incoming damage); an unclaimed pick auto-resolves
  randomly when the timer runs out
- Added two new enemy types for variety: **Bomber** (fast suicide rusher that explodes on
  contact — better to kill it at range) and **Shielded** (blocks most frontal sword damage
  unless you dash in, or dash just before hitting it, to flank it)

### 7. Light mode
I considered a straightforward CSS-only toggle first, but realized the game scene itself
(sky, sun/moon, skyline, rooftop) is hand-drawn on canvas, not styled with CSS — a
CSS-only toggle would have left the game world stuck in night mode even with light UI
panels. So I built a matched pair of theme palettes: CSS variables for the UI chrome (HUD,
buttons, overlays), and a parallel JS color palette for the canvas scene, both swapped
together by one Light/Dark toggle button.

---

*I'll keep adding to this file as the game changes.*
